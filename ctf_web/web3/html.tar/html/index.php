<?php
$miwen="==NEIqxn00JM8IIndEULdEULvOzMvEartSKnkOzMiETpyMzs";

function encode($str){
    $_o=strrev($str);
    // echo $_o;

    for($_0=0;$_0<strlen($_o);$_0++){

        $_c=substr($_o,$_0,1);
        $__=ord($_c)+1;
        $_c=chr($__);
        $_=$_.$_c;
    }
    return str_rot13(strrev(base64_encode($_)));
}

highlight_file(__FILE__);
echo "I_believe_you_can_solve_it!!!!! :)<br/>";
?>
